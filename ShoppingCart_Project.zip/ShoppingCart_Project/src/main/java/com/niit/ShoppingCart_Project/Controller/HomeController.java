package com.niit.ShoppingCart_Project.Controller;

import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingCartCoreApp.DAO.CategoryDAO;
import com.niit.shoppingCartCoreApp.DAO.UserDAO;
import com.niit.shoppingCartCoreApp.Model.Category;
import com.niit.shoppingCartCoreApp.Model.User; 


@Controller
public class HomeController {
		 
Logger log = LoggerFactory.getLogger(HomeController.class);
	
	@Autowired
	private User user;	
	@Autowired
	private CategoryDAO categoryDAO;
	@Autowired
	private UserDAO userDAO;
	@Autowired
	private Category category;
	
	@RequestMapping("/hello")
	public ModelAndView showMessage(@RequestParam(value = "name", required = false, defaultValue = "World") String name, HttpSession session) {
		System.out.println("in controller");
		log.debug("starting of the method onLoad");
		ModelAndView mv = new ModelAndView("/home");
		//session.setAttribute("category", category);
		//session.setAttribute("categoryDAO", categoryDAO.list());
		log.debug("ending of the method on load");
		return mv;
	}
		
	@RequestMapping(value = "user/register", method = RequestMethod.POST)
	public ModelAndView registeruser(@ModelAttribute User user) {
	    System.out.println(user.getName()+" , "+user.getPassword()); 
	    user.setUserrole("ROLE_USER");
		userDAO.saveorupdate(user);
		ModelAndView mv = new ModelAndView("/home");
		mv.addObject("sucessMessage", user.getName()+" ,you are Successfully Registered in Shopping Cart");
		return mv;
	}
	
	@RequestMapping("/registerHere")
	public ModelAndView registerHere() {
		ModelAndView mv = new ModelAndView("Register");
		mv.addObject("user", user);
		mv.addObject("isuserClickedRegisterHere", "true");
		return mv;
	}
	
	@RequestMapping("/loginHere")
	public ModelAndView loginHere() {
		ModelAndView mv = new ModelAndView("Login");
		mv.addObject("user", user);
		mv.addObject("isuserClickedLoginHere", "true");
		return mv;
	}
	
	@RequestMapping("user/loginHere")
	public ModelAndView userLoginHere() {
		ModelAndView mv = new ModelAndView("Login");		
		return mv;
	}
	
	
	/* Testing for Admin Home Page */
	@RequestMapping("/adminHere")
	public ModelAndView adminPage() {
		ModelAndView mv = new ModelAndView("adminhome");
		//mv.addObject("user", user);
		//mv.addObject("isuserClickedRegisterHere", "true");
		return mv;
	}
	
	
}

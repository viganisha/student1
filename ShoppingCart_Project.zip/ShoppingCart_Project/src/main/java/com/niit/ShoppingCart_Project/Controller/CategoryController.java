package com.niit.ShoppingCart_Project.Controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingCartCoreApp.DAO.CategoryDAO;
import com.niit.shoppingCartCoreApp.Model.Category;
@Controller
public class CategoryController 
{
	@Autowired
	private CategoryDAO categoryDAO;
	@Autowired
	private Category category;
	

	@RequestMapping("/category/add")
	public ModelAndView addCategory(@ModelAttribute Category category) 
	{
		ModelAndView mv = new ModelAndView("category");
		System.out.println("Inside add category");
		System.out.println(category.getCategoryid());
		categoryDAO.saveOrUpdate(category);
		mv.addObject("categoryList", categoryDAO.list());
	  return mv;
	 }

	
	@RequestMapping("/getAllCategories")
	public ModelAndView getAllCategories() {

		System.out.println("getAllCategories");
		
		List<Category> categoryList = categoryDAO.list();
		
		ModelAndView mv = new ModelAndView("/categoryList");
		mv.addObject("categoryList", categoryList);

		return mv;
	}
	
	int catID = 0;
	
	//@RequestMapping("/category/add/category/edit/{categoryid}")
	@RequestMapping("category/edit/{categoryid}")
	public ModelAndView updateCategory(@ModelAttribute Category category,@PathVariable ("categoryid") int id)
	{
		ModelAndView mv = new ModelAndView("categoryedit");
		System.out.println(id);
		catID = id;
		category = categoryDAO.get(id);
		mv.addObject("category", category);		
		mv.addObject("categoryList", categoryDAO.list());
		return mv;		
	}
	
	//@RequestMapping("/category/edit/category/remove/{categoryid}")
	@RequestMapping("/category/remove/{categoryid}")
	public ModelAndView deleteCategory(@PathVariable ("categoryid") int id)
	{
		System.out.println("hello");
		System.out.println(id);
		ModelAndView mv = new ModelAndView("category");
		categoryDAO.delete(id);
		mv.addObject("category", category);
		mv.addObject("categoryList", categoryDAO.list());
		return mv;	
	}

	@RequestMapping("/category/edit")
	public ModelAndView addeditCategory(@ModelAttribute Category category) 
	{		
		System.out.println("Inside Edit category");
		category.setCategoryid(catID);
		System.out.println(category.getCategoryid());		
		categoryDAO.saveOrUpdate(category);
		
		ModelAndView mv = new ModelAndView("category");
		mv.addObject("categoryList", categoryDAO.list());
		return mv;
	 }

}
package com.niit.ShoppingCart_Project.Controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingCartCoreApp.DAO.CartDAO;
import com.niit.shoppingCartCoreApp.Model.Cart;
import com.niit.shoppingCartCoreApp.Model.Supplier;
@Controller
public class CartController 
{
	@Autowired
	private CartDAO cartDAO;
	@Autowired
	private Cart cart;
	@RequestMapping("/cart/add")                          
	public ModelAndView addCart(@ModelAttribute Cart cart) 
	{
		ModelAndView mv = new ModelAndView("cart");
		System.out.println("Inside add cart");
		System.out.println(cart.getCartid());
		cartDAO.saveorupdate(cart);
		mv.addObject("cartList", cartDAO.list());
	  return mv;
	 }
}
package com.niit.ShoppingCart_Project.Controller;
import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.ModelAndView;
import com.niit.shoppingCartCoreApp.DAO.ProductDAO;
import com.niit.shoppingCartCoreApp.Model.Product;
@Controller
public class ProductController 
{
	@Autowired
	private ProductDAO productDAO;
	@Autowired
	private Product product;
	private Path path;
	
	@RequestMapping("/product/add")
	public ModelAndView addProduct(@ModelAttribute Product product,BindingResult result, HttpServletRequest request) 
	{
		ModelAndView mv = new ModelAndView("product");
		System.out.println("Inside add product");
		System.out.println(product.getProductid());
		productDAO.saveorupdate(product);
		
		MultipartFile productImage = product.getImage();
        String rootDirectory = request.getSession().getServletContext().getRealPath("/");
        System.out.println(rootDirectory.toString());
        path = Paths.get(rootDirectory + "/WEB-INF/Views/img/" + product.getProductid() + ".jpg");
        if(productImage != null && !productImage.isEmpty()){
            try {
                productImage.transferTo(new File(path.toString()));
            } catch (Exception ex){
                ex.printStackTrace();
                throw new RuntimeException("Product image saving failed", ex);
            }
        }

		mv.addObject("productList", productDAO.list());
	  return mv;
	 }

		
	@RequestMapping("/getAllProducts")
	public ModelAndView getAllProducts() {

		System.out.println("getAllProducts");
		List<Product> productList = productDAO.list();
		ModelAndView mv = new ModelAndView("/productList");
		mv.addObject("productList", productList);
		return mv;
	}
	int prdID=0;
	@RequestMapping("product/edit/{productid}")
	public ModelAndView updateProduct(@ModelAttribute Product product ,@PathVariable ("productid") int id)
	{
		ModelAndView mv = new ModelAndView("productedit");
		System.out.println(id);
		prdID = id;
		product = productDAO.get(id);
		mv.addObject("product", product);		
		
		mv.addObject("productList", productDAO.list());
		return mv;
	}
	
	@RequestMapping("product/remove/{productid}")
	public ModelAndView deleteProduct(@PathVariable ("productid") int id)
	{
		System.out.println("hello");
		System.out.println(id);
		ModelAndView mv = new ModelAndView("product");
		productDAO.delete(id);
		mv.addObject("product", product);
		mv.addObject("productList", productDAO.list());
		return mv;	
	}
	
	@RequestMapping("/product/edit")
	public ModelAndView addeditProduct(@ModelAttribute Product product) 
	{
		ModelAndView mv = new ModelAndView("product");
		System.out.println("Inside edit  category");
		product.setProductid(prdID);
		System.out.println(product.getProductid());
		productDAO.saveorupdate(product);
		mv.addObject("productList", productDAO.list());
	  return mv;
	 }
	
	/* Testing for Admin Home Page */
	@RequestMapping("/productHere")
	public ModelAndView allProductsPage() {
		
		System.out.println("getAllProducts");
		List<Product> productList = productDAO.list();
		ModelAndView mv = new ModelAndView("allProducts");
		mv.addObject("productList", productList);		
		return mv;
	}
}
package com.niit.ShoppingCart_Project.Controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.niit.shoppingCartCoreApp.DAO.SupplierDAO;
import com.niit.shoppingCartCoreApp.Model.Supplier;
@Controller
public class SupplierController 
{
	@Autowired
	private SupplierDAO supplierDAO;
	@Autowired
	private Supplier supplier;
	

	@RequestMapping("/supplier/add")
	public ModelAndView addSupplier(@ModelAttribute Supplier supplier) 
	{
		ModelAndView mv = new ModelAndView("supplier");
		System.out.println("Inside add supplier");
		System.out.println(supplier.getSupplierid());
		supplierDAO.saveorupdate(supplier);
		mv.addObject("supplierList", supplierDAO.list());
		return mv;
	}
	   
	@RequestMapping("/getAllsuppliers")
	public ModelAndView getAllsuppliers() {
		System.out.println("getAllsuppliers");
		List<Supplier> supplierList = supplierDAO.list();
		ModelAndView mv = new ModelAndView("/supplierList");
		mv.addObject("supplierList", supplierList);
		return mv;
	}
	
	int supID=0;
	@RequestMapping("supplier/edit/{supplierid}")
	public ModelAndView updateSupplier(@ModelAttribute Supplier supplier,@PathVariable ("supplierid") int id)
	{
		ModelAndView mv = new ModelAndView("supplieredit");
		System.out.println(id);
	    supID = id;
		supplier= supplierDAO.get(id);
		mv.addObject("supplier", supplier);	
		mv.addObject("supplierList", supplierDAO.list());
		return mv;		
	}
	
	@RequestMapping("/supplier/remove/{supplierid}")
	public ModelAndView deleteSupplier(@PathVariable ("supplierid") int id)
	{
		System.out.println("hello");
		System.out.println(id);
		ModelAndView mv = new ModelAndView("supplier"); 
		supplierDAO.delete(id);
		mv.addObject("supplier", supplier);
		mv.addObject("supplierList", supplierDAO.list());
		return mv;	
	}

	@RequestMapping("/supplier/edit")
	public ModelAndView addeditCategory(@ModelAttribute Supplier supplier) 
	{		
		System.out.println("Inside edit supplier");
		supplier.setSupplierid(supID);
		System.out.println(supplier.getSupplierid());
		supplierDAO.saveorupdate(supplier);
		
		ModelAndView mv = new ModelAndView("supplier");
		mv.addObject("supplierList", supplierDAO.list());
	    return mv;
	 }

}
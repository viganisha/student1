package com.niit.shoppingCartCoreApp.Test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingCartCoreApp.DAO.CategoryDAO;
import com.niit.shoppingCartCoreApp.Model.Category;

public class CategoryTest 
{
	public static void main(String[] args) { 
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingCartCoreApp");
		context.refresh();
		CategoryDAO categoryDAO=(CategoryDAO)context.getBean("categoryDAO");
		Category category =(Category)context.getBean("category");
		category.setCategoryid(12);
		category.setName("gsna12");
		category.setDescription("gsde222s");
		System.out.println(category.getCategoryid()+" "+category.getName()+" "+category.getDescription());
		
		categoryDAO.saveOrUpdate(category);
		System.out.println("no of category"+ categoryDAO.list().size());
		context.close();
	}
}

package com.niit.shoppingCartCoreApp.Model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.PrimaryKeyJoinColumn;
import javax.persistence.Table;
import javax.persistence.JoinTable;
import javax.persistence.ManyToOne;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.FetchType;

import javax.persistence.Transient;

import org.springframework.web.multipart.MultipartFile;
import org.springframework.stereotype.Component;

@Entity
@Table
@Component

public class Product{
		
	@Id
	private int productid;
	private String name;	
	private String description;
	private int price;
	
	@ManyToOne
	@JoinColumn(name="categoryid")
	private Category category;
	
	
	@Transient
	private MultipartFile image; 
	
	public MultipartFile getImage() {
	return image;
	}
	
	public void setImage(MultipartFile image) { 
	this.image = image;
	}
	
	public Product(){		
	}
	
	public int getProductid() {
		return productid;
	}

	public void setProductid(int productid) {
		this.productid = productid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public int getPrice() {
		return price;
	}

	public void setPrice(int price) {
		this.price = price;
	}
	
	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}
}
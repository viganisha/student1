package com.niit.shoppingCartCoreApp.Test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingCartCoreApp.DAO.ProductDAO;
import com.niit.shoppingCartCoreApp.Model.Product;

public class ProductTest {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingCartCoreApp");
		context.refresh();
		ProductDAO productDAO=(ProductDAO)context.getBean("productDAO");
		Product product =(Product)context.getBean("product");
		product.setProductid(11);
		product.setName("gsna11");
		product.setDescription("gsdes111s");
		product.setPrice(50000);
		System.out.println(product.getProductid()+" "+product.getName()+" "+product.getDescription());
		productDAO. saveorupdate(product);
	}
}

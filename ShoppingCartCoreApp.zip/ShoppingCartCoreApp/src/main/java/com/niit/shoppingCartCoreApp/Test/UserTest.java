package com.niit.shoppingCartCoreApp.Test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingCartCoreApp.DAO.UserDAO;
import com.niit.shoppingCartCoreApp.Model.User;

public class UserTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingCartCoreApp");
		context.refresh();
		UserDAO userDAO=(UserDAO)context.getBean("userDAO");
		User user =(User)context.getBean("user");
		user.setUserid(1002);
		user.setName("Balaji");
		user.setPassword("bala");
		user.setMobile("9090909090");
		user.setMail("bala@gmail.com");
		user.setAddress("Valavanur");
		System.out.println(user.getUserid()+" "+user.getName()+" "+user.getAddress());
		userDAO.saveorupdate(user);
	}
}

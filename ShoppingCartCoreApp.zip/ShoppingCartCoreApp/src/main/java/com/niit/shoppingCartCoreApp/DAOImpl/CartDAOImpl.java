package com.niit.shoppingCartCoreApp.DAOImpl;

//import org.hibernate.HibernateException;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

//import org.slf4j.Logger;
//import org.slf4j.LoggerFactory;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingCartCoreApp.DAO.CartDAO;
import com.niit.shoppingCartCoreApp.Model.Cart;

import java.util.List;

@Repository("cartDAO")
public class CartDAOImpl implements CartDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public CartDAOImpl() {
	}

	public CartDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void saveorupdate(Cart Cart) {
		Session ses = sessionFactory.openSession();
		Transaction tx = ses.beginTransaction();
		ses.saveOrUpdate(Cart);
		tx.commit();
		ses.close();
	}

	@Transactional
	public void delete(int id) {
		Cart cartToDelete = new Cart();
		cartToDelete.setCartid(id);
		sessionFactory.getCurrentSession().delete(id);
	}

	@Transactional
	public Cart get(int id) {
		String hql = "from Cart where id=+";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Cart> listCart = (List<Cart>)query.list();
		if (listCart != null && listCart.isEmpty()) {
			return listCart.get(0);
		}
		return null;
	}

	@Transactional
	@SuppressWarnings("unchecked")
	public List<Cart> list() {
		String hql = "from Cart";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Cart> listCart = (List<Cart>) query.list();
		return listCart;
	}

	@Transactional
	public Long getTotalAmount(int id) {
		String hql = "select sum(price)from Cart where userid=+";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		Long sum = (Long) query.uniqueResult();
		return sum;
	}
}
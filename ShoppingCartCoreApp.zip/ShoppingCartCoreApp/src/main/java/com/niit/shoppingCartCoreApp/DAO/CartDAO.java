package com.niit.shoppingCartCoreApp.DAO;

import java.util.List;
import com.niit.shoppingCartCoreApp.Model.Cart;


public interface CartDAO {
	public List<Cart> list();
	public Cart get(int id); 
	public void saveorupdate(Cart Cart);
	public void delete(int id);
	public Long getTotalAmount(int id);
}
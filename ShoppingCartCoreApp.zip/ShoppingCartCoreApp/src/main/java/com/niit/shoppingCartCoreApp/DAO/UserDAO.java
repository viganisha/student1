package com.niit.shoppingCartCoreApp.DAO;

import java.util.List;

import com.niit.shoppingCartCoreApp.Model.User;

public interface UserDAO {
	public List<User> list();
	public User get(int id);
	public void  saveorupdate(User user);
	public void delete(int id);
	public boolean isValidUser(String name,String password);
	public boolean getValue(String name,String password);
}
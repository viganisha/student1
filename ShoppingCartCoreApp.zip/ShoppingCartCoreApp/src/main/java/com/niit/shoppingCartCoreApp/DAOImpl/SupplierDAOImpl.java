package com.niit.shoppingCartCoreApp.DAOImpl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingCartCoreApp.DAO.SupplierDAO;
import com.niit.shoppingCartCoreApp.Model.Supplier;

//import org.springframework.transaction.event.TransactionalEventListener;
import java.util.List;

@Repository("supplierDAO")
public class SupplierDAOImpl implements SupplierDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	public SupplierDAOImpl() {
	}

	public SupplierDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void saveorupdate(Supplier Supplier) {
		Session ses = sessionFactory.openSession();
		Transaction tx=ses.beginTransaction();
		ses.saveOrUpdate(Supplier);
		tx.commit();
		ses.close();
	}

	@Transactional
	public void delete(int id) {
		Session sesDel = sessionFactory.openSession();
		Transaction tx=sesDel.beginTransaction();
		Supplier supplierToDelete = (Supplier) sesDel.load(Supplier.class, id);
		sesDel.delete(supplierToDelete);
		tx.commit();
		sesDel.close();
	}
	
	@Transactional
	public Supplier get(int id) {
		Session sesUpd = sessionFactory.openSession();		
		Supplier supplierUpdate = (Supplier) sesUpd.load(Supplier.class, id);
		return supplierUpdate;
	}
		

	@Transactional
	@SuppressWarnings("unchecked")
	public List<Supplier> list() {
		String hql = "from Supplier";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Supplier> listSupplier = (List<Supplier>) query.list();
		return listSupplier;
	}
}
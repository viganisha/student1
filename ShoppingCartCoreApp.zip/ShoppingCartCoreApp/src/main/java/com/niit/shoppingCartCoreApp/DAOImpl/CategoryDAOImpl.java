package com.niit.shoppingCartCoreApp.DAOImpl;


import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingCartCoreApp.DAO.CategoryDAO;
import com.niit.shoppingCartCoreApp.Model.Category;

//import org.springframework.transaction.event.TransactionalEventListener;
import java.util.List;

@Repository("categoryDAO") 
public  class CategoryDAOImpl implements CategoryDAO {
	
	Logger log = LoggerFactory.getLogger(CategoryDAOImpl.class);
	
	@Autowired
	private SessionFactory sessionFactory;

	public CategoryDAOImpl() {
	}

	public CategoryDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void saveOrUpdate(Category category) {
		Session ses = sessionFactory.openSession();
		Transaction tx=ses.beginTransaction();
		ses.saveOrUpdate(category);
		tx.commit();
		ses.close();
	}

	@Transactional
	public void delete(int id) {
		Session sesDel = sessionFactory.openSession();
		Transaction tx=sesDel.beginTransaction();
		Category categoryToDelete = (Category) sesDel.load(Category.class, id);
		sesDel.delete(categoryToDelete);
		tx.commit();
		sesDel.close();
		
		/*
		categoryToDelete.setCategoryid(id);
		try{
		sessionFactory.getCurrentSession().delete(id);
		}
		catch(HibernateException e){
			e.printStackTrace();
			log.error(e.getMessage());
		}*/
	}
	
	@Transactional
	public Category get(int id) {
		Session sesUpd = sessionFactory.openSession();		
		Category categoryUpdate = (Category) sesUpd.load(Category.class, id);
		return categoryUpdate;
		
		/*
		String hql = "from Category where categoryid=+";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Category> listCategory = (List<Category>) query.list();
		if (listCategory != null && listCategory.isEmpty()) {
			return listCategory.get(0);
		}
		return null;
		*/		
	}

	@Transactional
	@SuppressWarnings("unchecked")
	public List<Category> list() {
		String hql = "from Category";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Category> listCategory = (List<Category>) query.list();
		return listCategory;
	}
}
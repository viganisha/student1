package com.niit.shoppingCartCoreApp.DAO;

import java.util.List;

import com.niit.shoppingCartCoreApp.Model.Supplier;

public interface SupplierDAO {
	public List<Supplier> list();
	public Supplier get(int id);
	public void saveorupdate(Supplier Supplier);
	public void delete(int id);
}
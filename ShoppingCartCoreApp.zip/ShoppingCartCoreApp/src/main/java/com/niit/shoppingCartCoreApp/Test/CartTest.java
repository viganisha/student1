package com.niit.shoppingCartCoreApp.Test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingCartCoreApp.DAO.CartDAO;
import com.niit.shoppingCartCoreApp.Model.Cart;


public class CartTest 
{
	public static void main(String[] args) { 
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingCartCoreApp");
		context.refresh();
		CartDAO cartDAO=(CartDAO)context.getBean("cartDAO");
		Cart cart =(Cart)context.getBean("cart");
		cart.setCartid(12);
		cart.setUserid(56);
		cart.setProductname("gsna12");
		cart.setProductprice(50000);
		System.out.println(cart.getCartid()+" "+cart.getUserid());
		
		cartDAO.saveorupdate(cart);
		System.out.println("no of cart"+ cartDAO.list().size());
		context.close();
	}
}
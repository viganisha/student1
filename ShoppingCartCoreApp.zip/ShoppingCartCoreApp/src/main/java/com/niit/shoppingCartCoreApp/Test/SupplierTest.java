package com.niit.shoppingCartCoreApp.Test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingCartCoreApp.DAO.SupplierDAO;
import com.niit.shoppingCartCoreApp.Model.Supplier;

public class SupplierTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingCartCoreApp");
		context.refresh();
		SupplierDAO supplierDAO=(SupplierDAO)context.getBean("supplierDAO");
		Supplier supplier =(Supplier)context.getBean("supplier");
		supplier.setSupplierid(11);
		supplier.setName("viganisha");
		supplier.setAddress("chennai");
		supplier.setAddress("CHENNAI");
		System.out.println(supplier.getSupplierid()+" "+supplier.getName()+" "+supplier.getAddress());
		supplierDAO.saveorupdate(supplier);
	}
}

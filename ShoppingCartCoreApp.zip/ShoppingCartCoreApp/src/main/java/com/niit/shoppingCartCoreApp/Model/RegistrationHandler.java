package com.niit.shoppingCartCoreApp.Model;


import com.niit.shoppingCartCoreApp.DAO.UserDAO;
import org.springframework.binding.message.MessageBuilder;
import org.springframework.binding.message.MessageContext;
 

public class RegistrationHandler {

		 
		public User initFlow(){
			return new User();
		}
	 
		public String validateDetails(User user,MessageContext messageContext){
			String status = "success";
			if(user.getUserid() == 0){
				messageContext.addMessage(new MessageBuilder().error().source(
						"userId").defaultText("UserId cannot be Empty").build());
				status = "failure";
			}	
			if(user.getMail().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"mail").defaultText("mail cannot be Empty").build());
			status = "failure";
		}		
		if(user.getMobile().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"mobile").defaultText("mobile cannot be Empty").build());
			status = "failure";
		}
		if(user.getPassword().isEmpty()){
			messageContext.addMessage(new MessageBuilder().error().source(
					"password").defaultText("password cannot be Empty").build());
			status = "failure";
		}
		if(user.getAddress().isEmpty()){
	messageContext.addMessage(new MessageBuilder().error().source(
			"address").defaultText("address cannot be Empty").build());
	status = "failure";
}
		if(user.getUserrole().isEmpty()){
	messageContext.addMessage(new MessageBuilder().error().source(
			"userrole").defaultText("userrole cannot be Empty").build());
	status = "failure";
}
return status;
}
}

			
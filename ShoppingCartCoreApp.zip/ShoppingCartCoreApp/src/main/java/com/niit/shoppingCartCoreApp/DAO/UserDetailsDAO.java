package com.niit.shoppingCartCoreApp.DAO;


import java.util.List;

import com.niit.shoppingCartCoreApp.Model.UserDetails;



public interface UserDetailsDAO {
	public List<UserDetails> list();
	public UserDetails get(int id);
	public void  saveorupdate(UserDetails userDetails);
	public void delete(int id);
}


package com.niit.shoppingCartCoreApp.DAOImpl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingCartCoreApp.DAO.ProductDAO;
import com.niit.shoppingCartCoreApp.Model.Product;

//import org.springframework.transaction.event.TransactionalEventListener;
import java.util.List;

@Repository("ProductDAO")
public class ProductDAOImpl implements ProductDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	public ProductDAOImpl() {
	}

	public ProductDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void saveorupdate(Product Product) {
		Session ses = sessionFactory.openSession();
		Transaction tx=ses.beginTransaction();
		ses.saveOrUpdate(Product);
		tx.commit();
		ses.close();
	}

	@Transactional
	public void delete(int id) {
		Session sesDel = sessionFactory.openSession();
		Transaction tx=sesDel.beginTransaction();
		Product productToDelete = (Product) sesDel.load(Product.class, id);
		sesDel.delete(productToDelete);
		tx.commit();
		sesDel.close();
	}
	@Transactional
	public Product get(int id) {
		Session sesUpd = sessionFactory.openSession();		
		Product productUpdate = (Product) sesUpd.load(Product.class, id);
		return productUpdate;
	}

	@Transactional
	@SuppressWarnings("unchecked")
	public List<Product> list() {
		String hql = "from Product";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Product> listProduct = (List<Product>) query.list();
		return listProduct;
	}
}
package com.niit.shoppingCartCoreApp.Test;
import static org.junit.Assert.assertEquals;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import com.niit.shoppingCartCoreApp.DAO.UserDAO;
public class TestUserDAO {
@Autowired 
static UserDAO userDAO;  
@BeforeClass
public static void init()
{
	AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
	context.scan("com.niit.shoppingCartCoreApp");
	context.refresh();
	userDAO=(UserDAO)context.getBean("userDAO");
	context.close();
}
@Test
public void UsersTestCase()
{
	int size = userDAO.list().size();
	assertEquals("use list test case", 5, size);
}
}
/*
 * @Autowired
static UserDetails userDetails;
static AnnotationConfigApplicationContext context;

 */
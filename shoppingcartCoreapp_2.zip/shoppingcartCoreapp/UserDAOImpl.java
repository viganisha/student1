package com.niit.shoppingcartCoreapp;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
//import org.springframework.transaction.event.TransactionalEventListener;
import java.util.List;

@Repository("userDAO")
public class UserDAOImpl implements UserDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	public UserDAOImpl() {
	}

	public UserDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void saveorupdate(User user) {
		Session ses = sessionFactory.openSession();
		Transaction tx=ses.beginTransaction();
		ses.saveOrUpdate(user);
		tx.commit();
		ses.close();
	}

	@Transactional
	public void delete(int id) {
		User UserToDelete = new User();
		UserToDelete.setId(id);
		sessionFactory.getCurrentSession().delete(id);
	}

	@Transactional
	public User get(int id) {
		String hql = "from User where id=+";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<User> listUser = (List<User>) query.list();
		if (listUser != null && listUser.isEmpty()) {
			return listUser.get(0);
		}
		return null;
		
	}

	@Transactional
	@SuppressWarnings("unchecked")
	public List<User> list() {
		String hql = "from User";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<User> listUser = (List<User>) query.list();
		return listUser;
	}
}
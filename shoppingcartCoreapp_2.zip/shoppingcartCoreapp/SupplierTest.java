package com.niit.shoppingcartCoreapp;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SupplierTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcartCoreapp");
		context.refresh();
		SupplierDAO supplierDAO=(SupplierDAO)context.getBean("supplierDAO");
		Supplier supplier =(Supplier)context.getBean("supplier");
		supplier.setId(11);
		supplier.setName("gsna11");
		supplier.setAddress("CHENNAI");
		System.out.println(supplier.getId()+" "+supplier.getName()+" "+supplier.getAddress());
		supplierDAO.saveorupdate(supplier);
	}
}

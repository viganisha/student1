package com.niit.shoppingcartCoreapp;

import java.util.List;

public interface UserDAO {
	public List<User> list();
	public User get(int id);
	public void  saveorupdate(User user);
	public void delete(int id);
}
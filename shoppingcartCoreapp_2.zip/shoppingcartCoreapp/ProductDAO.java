package com.niit.shoppingcartCoreapp;

import java.util.List;

public interface ProductDAO {
	public List<Product> list();
	public Product get(int id);
	public void  saveorupdate(Product product);
	public void delete(int id);
}
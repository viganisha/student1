package com.niit.shoppingcartCoreapp.DAO;

import java.util.List;

import com.niit.shoppingcartCoreapp.Model.Product;

public interface ProductDAO {
	public List<Product> list();
	public Product get(int id);
	public void  saveorupdate(Product product);
	public void delete(int id);
}
package com.niit.shoppingcartCoreapp.DAO;


import java.util.List;

import com.niit.shoppingcartCoreapp.Model.UserDetails;



public interface UserDetailsDAO {
	public List<UserDetails> list();
	public UserDetails get(int id);
	public void  saveorupdate(UserDetails userDetails);
	public void delete(int id);
}


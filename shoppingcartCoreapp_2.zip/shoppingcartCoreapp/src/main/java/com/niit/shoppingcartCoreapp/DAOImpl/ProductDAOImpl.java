package com.niit.shoppingcartCoreapp.DAOImpl;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.shoppingcartCoreapp.DAO.ProductDAO;
import com.niit.shoppingcartCoreapp.Model.Product;

//import org.springframework.transaction.event.TransactionalEventListener;
import java.util.List;

@Repository("ProductDAO")
public class ProductDAOImpl implements ProductDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	public ProductDAOImpl() {
	}

	public ProductDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void saveorupdate(Product Product) {
		Session ses = sessionFactory.openSession();
		Transaction tx=ses.beginTransaction();
		ses.saveOrUpdate(Product);
		tx.commit();
		ses.close();
	}

	@Transactional
	public void delete(int id) {
		Product ProductToDelete = new Product();
		ProductToDelete.setId(id);
		sessionFactory.getCurrentSession().delete(id);
	}

	@Transactional
	public Product get(int id) {
		String hql = "from Product where id=+";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Product> listProduct = (List<Product>) query.list();
		if (listProduct != null && listProduct.isEmpty()) {
			return listProduct.get(0);
		}
		return null;
		
	}

	@Transactional
	@SuppressWarnings("unchecked")
	public List<Product> list() {
		String hql = "from Product";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Product> listProduct = (List<Product>) query.list();
		return listProduct;
	}
}
package com.niit.shoppingcartCoreapp.Test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartCoreapp.DAO.UserDAO;
import com.niit.shoppingcartCoreapp.Model.User;

public class UserTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcartCoreapp");
		context.refresh();
		UserDAO userDAO=(UserDAO)context.getBean("userDAO");
		User user =(User)context.getBean("user");
		user.setId(11);
		user.setName("viganisha");
		user.setPassword("hello");
		user.setMobile("044-23451245");
		user.setMail("gs");
		user.setAddress("CHENNAI");
		System.out.println(user.getId()+" "+user.getName()+" "+user.getAddress());
		userDAO.saveorupdate(user);
	}
}

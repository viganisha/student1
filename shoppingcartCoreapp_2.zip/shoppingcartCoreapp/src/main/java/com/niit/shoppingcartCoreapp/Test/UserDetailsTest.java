package com.niit.shoppingcartCoreapp.Test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartCoreapp.DAO.UserDetailsDAO;
import com.niit.shoppingcartCoreapp.Model.UserDetails;

public class UserDetailsTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcartCoreapp");
		context.refresh();
		UserDetailsDAO userDetailsDAO=(UserDetailsDAO)context.getBean("userdetailsDAO");
		UserDetails userDetails =(UserDetails)context.getBean("userDetails");
		//userDetails.setId(11);
		userDetails.setName("raj");
		userDetails.setPassword("hello");
		userDetails.setMobile("044-23451244");
		userDetails.setMail("raj. cse@gmail.com");
		userDetails.setAddress("trichy");
		userDetails.setAdmin(Byte.valueOf("0"));
		System.out.println(userDetails.getId()+" "+userDetails.getName()+" "+userDetails.getAddress());
		userDetailsDAO.saveorupdate(userDetails);
	}
}
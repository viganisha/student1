package com.niit.shoppingcartCoreapp.Test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartCoreapp.DAO.SupplierDAO;
import com.niit.shoppingcartCoreapp.Model.Supplier;

public class SupplierTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcartCoreapp");
		context.refresh();
		SupplierDAO supplierDAO=(SupplierDAO)context.getBean("supplierDAO");
		Supplier supplier =(Supplier)context.getBean("supplier");
		supplier.setId(11);
		supplier.setName("viganisha");
		supplier.setAddress("chennai");
		supplier.setAddress("CHENNAI");
		System.out.println(supplier.getId()+" "+supplier.getName()+" "+supplier.getAddress());
		supplierDAO.saveorupdate(supplier);
	}
}

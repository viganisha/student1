package com.niit.shoppingcartCoreapp.DAO;

import java.util.List;

import com.niit.shoppingcartCoreapp.Model.Category;

public interface CategoryDAO {
	public List<Category> list();
	public Category get(int id);
	public void saveOrUpdate(Category Category);
	public void delete(int id);
}
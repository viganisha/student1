package com.niit.shoppingcartCoreapp.Test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.shoppingcartCoreapp.DAO.UserDAO;
import com.niit.shoppingcartCoreapp.Model.UserDetails;


public class TestUserDAO {

@Autowired 
static UserDAO userDAO;  
@Autowired
static UserDetails userDetails;

static AnnotationConfigApplicationContext context;
@BeforeClass
public static void init()
{
	context=new AnnotationConfigApplicationContext();
	userDAO=(UserDAO)context.getBean("userDAO");
	context.scan("com.niit.shoppingcartCoreapp");
	context.refresh();
}

@Test
public void UsersTestCase()
{
	int size=userDAO.list().size();
	assertEquals("use list test case", 5, size);
}
}
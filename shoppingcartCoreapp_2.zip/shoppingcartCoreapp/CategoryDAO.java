package com.niit.shoppingcartCoreapp;

import java.util.List;

public interface CategoryDAO {
	public List<Category> list();
	public Category get(int id);
	public void saveOrUpdate(Category Category);
	public void delete(int id);
}
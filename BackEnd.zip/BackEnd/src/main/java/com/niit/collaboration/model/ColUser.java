package com.niit.collaboration.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Entity
@Table(name="ColUser")
@Component
@Repository("coluser")
public class ColUser implements java.io.Serializable{
	
	@Id
	private int userid; 
	private String name;
	private String mail;
	private String password;
	private String mobile;  
	private String address;
	private String userrole;

	public ColUser(int userid, String name, String mail, String password, String mobile, String address, String userrole) {
		this.userid = userid;
		this.name = name;
		this.mail = mail;
		this.password = password; 
		this.mobile = mobile;
		this.address = address;
		this.userrole = userrole;
	} 
 
	public ColUser(){}
	 
	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getMail() {
		return mail;
	}

	public void setMail(String mail) {
		this.mail = mail;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getUserrole() {
		return userrole;
	}

	public void setUserrole(String userrole) {
		this.userrole = userrole;
	}

}

package com.niit.collaboration.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaboration.dao.EventDAO;
import com.niit.collaboration.model.Event; 

public class EventTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.collaboration");
		context.refresh();
		
		EventDAO eventDAO=(EventDAO)context.getBean("eventDAO");		 
		Event event =(Event)context.getBean("event");
		event.setEventid(10010101);
		event.setTitle("Birthday");
		event.setDescription("Viganisha Birthday May Month 26th date");
		System.out.println(event.getTitle()+" "+event.getDescription());
				
		eventDAO.saveorupdate(event);
		
		context.close(); 
	} 
}

package com.niit.collaboration.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaboration.dao.CustomerDAO;
import com.niit.collaboration.model.Customer;


public class CustomerTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.collaboration");
		context.refresh();
		CustomerDAO customerDAO=(CustomerDAO)context.getBean("customerDAO");
		Customer customer =(Customer)context.getBean("customer");
		customer.setId(121);
		customer.setFirstName("Nila");
		customer.setLastName("Gunasekaran");
		customer.setEmail("nila.cse@gmail.com");		
 		customer.setMobile("9090909090");
 		customer.setDateOfBirth("26-05-1997"); 
		System.out.println(customer.getFirstName()+" "+customer.getEmail()+" "+customer.getLastName());
				
		customerDAO.saveorupdate(customer);
		context.close(); 
	}
}
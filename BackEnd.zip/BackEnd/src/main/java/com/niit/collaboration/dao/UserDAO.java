package com.niit.collaboration.dao;


import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.collaboration.model.ColUser;


@Repository("userDAO")
public class UserDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public UserDAO() {		
	}
	
	public UserDAO(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
			
	public void saveorupdate(ColUser user) {
				
		Session ses = sessionFactory.openSession();
		Transaction tx=ses.beginTransaction(); 
		ses.saveOrUpdate(user);
		tx.commit();
		ses.close();
	}

	@Transactional
	public void delete(int id) {
						
		Session sesDel = sessionFactory.openSession();
		Transaction tx=sesDel.beginTransaction();
		ColUser userToDelete = (ColUser) sesDel.load(ColUser.class, id);
		sesDel.delete(userToDelete);
		tx.commit();
		sesDel.close();
	}

	@Transactional
	public ColUser get(int id) {
		
		String hql = "from ColUser where id="+id;		 
		Query query = (Query<ColUser>) sessionFactory.getCurrentSession().createQuery(hql);
		List<ColUser> listUser = (List<ColUser>) query.list();
		if (listUser != null && listUser.isEmpty()) {
			return listUser.get(0);
		}
		return listUser.get(0);
	}

	@Transactional
	@SuppressWarnings("unchecked")
	public List<ColUser> list() {
		
		String hql = "from ColUser";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<ColUser> listUser = (List<ColUser>) query.list();
		return listUser;
	}
	public String role= "";
	
	@Transactional
	public boolean isValidUser(String name,String password) {
		System.out.println("Is Valid User");
		String hql = "from ColUser where name= '"+name+"' and password='"+password+"'";
		Query qry = (Query) sessionFactory.getCurrentSession().createQuery(hql);
				
		List<ColUser> list = (List<ColUser>) qry.list();		
		
		if (list==null || list.isEmpty())
		{
			return false;
		}
		else
		{
			return true;
		}
	} 
	
	@Transactional
	public boolean getValue(String name,String password){

		Query qury = sessionFactory.getCurrentSession().createQuery("select u.userrole,u.name,u.password from ColUser u where name = '"+name+"' and password='"+password+"' and userrole = 'student'");
		 
		List<ColUser> list = (List<ColUser>) qury.list();		
		
		if (list==null || list.isEmpty())
		{
			return false;
		}
		else
		{
			return true;

		}

	}

}


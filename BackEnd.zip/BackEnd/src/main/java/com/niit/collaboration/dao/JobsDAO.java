package com.niit.collaboration.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.collaboration.model.ColJobs;


@Repository("jobsDAO")
public class JobsDAO {


	@Autowired
	private SessionFactory sessionFactory;

	public JobsDAO() {		
	}
	
	public JobsDAO(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
			
	public void saveorupdate(ColJobs job) {
				
		Session ses = sessionFactory.openSession();
		Transaction tx=ses.beginTransaction(); 
		ses.saveOrUpdate(job);
		tx.commit();
		ses.close();
	}
 
	@Transactional
	public void delete(int id) {
						
		Session sesDel = sessionFactory.openSession();
		Transaction tx=sesDel.beginTransaction();
		ColJobs jobsToDelete = (ColJobs) sesDel.load(ColJobs.class, id);
		sesDel.delete(jobsToDelete);
		tx.commit();
		sesDel.close();
	}

	@Transactional
	public ColJobs get(int id) {
		
		String hql = "from ColJobs where id="+id;		 
		Query query = (Query<ColJobs>) sessionFactory.getCurrentSession().createQuery(hql);
		List<ColJobs> listJobs = (List<ColJobs>) query.list();
		if (listJobs != null && listJobs.isEmpty()) {
			return listJobs.get(0);
		}
		return listJobs.get(0);
	}

	@Transactional
	@SuppressWarnings("unchecked")
	public List<ColJobs> list() {
		
		String hql = "from ColJobs";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<ColJobs> listJobs = (List<ColJobs>) query.list();
		return listJobs;
	}
}

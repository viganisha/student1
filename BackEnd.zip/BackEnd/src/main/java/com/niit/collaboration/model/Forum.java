package com.niit.collaboration.model;

import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Table(name="Forum")
@Component
public class Forum implements java.io.Serializable{

	@Id
	private int forumid;
	private String message;
	private Date time;
	
	public Forum(int forumid,String message,Date time){
		this.forumid = forumid;
		this.message = message;
		this.time = time;
	}
	
	public Forum(){}
	
	public int getForumid() {
		return forumid;
	}
	public void setForumid(int forumid) {
		this.forumid = forumid;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public Date getTime() {
		return time;
	}
	public void setTime(Date time) {
		this.time = time;
	}
}

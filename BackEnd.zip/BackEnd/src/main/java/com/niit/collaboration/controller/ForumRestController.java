package com.niit.collaboration.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.niit.collaboration.dao.ForumDAO;
import com.niit.collaboration.model.Forum;


@RestController
public class ForumRestController {

	
	@Autowired
	private ForumDAO forumDAO;

	@Autowired
	private Forum forum;
	
	@GetMapping("/forums")
	public List getForums() {
		return forumDAO.list();
	}

	@GetMapping("/forums/{id}")
	public ResponseEntity getForum(@PathVariable("id") int id) {

		Forum forum = forumDAO.get(id);
		if (forum == null) {
			return new ResponseEntity("No Forum found for ID " + id, HttpStatus.NOT_FOUND);
		} 

		return new ResponseEntity(forum, HttpStatus.OK);
	}

	@RequestMapping(value="/forums", method=RequestMethod.POST)
	public ResponseEntity<Forum> createForum(@RequestBody Forum forum) {
		
		forumDAO.saveorupdate(forum);

		return new ResponseEntity<Forum>(forum, HttpStatus.OK);
	}

	@DeleteMapping("/forums/{id}")
	public ResponseEntity deleteForum(@PathVariable int id) {

		System.out.println(id);
		forumDAO.delete(id);	
		
		return new ResponseEntity(id, HttpStatus.OK);

	}

	@PutMapping("/forums/{id}")
	public ResponseEntity updateForum(@PathVariable int id, @RequestBody Forum forum) {

		forumDAO.saveorupdate(forum);

		if (null == forum) {
			return new ResponseEntity("No Forum found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(forum, HttpStatus.OK);
	}

}

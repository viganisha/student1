  package com.niit.collaboration.dao;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;


import com.niit.collaboration.model.Customer;


@Repository("customerDAO")
public class CustomerDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public CustomerDAO() {		
	}
	
	public CustomerDAO(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
			
	public void saveorupdate(Customer customer) {
				
		Session ses = sessionFactory.openSession();
		Transaction tx=ses.beginTransaction(); 
		ses.saveOrUpdate(customer);
		tx.commit();
		ses.close();
	}
 
	@Transactional
	public void delete(int id) {
						
		Session sesDel = sessionFactory.openSession();
		Transaction tx=sesDel.beginTransaction();
		Customer cusToDelete = (Customer) sesDel.load(Customer.class, id);
		sesDel.delete(cusToDelete);
		tx.commit();
		sesDel.close();
	}

	@Transactional
	public Customer get(int id) {
		
		String hql = "from Customer where id="+id;		 
		Query query = (Query<Customer>) sessionFactory.getCurrentSession().createQuery(hql);
		List<Customer> listUser = (List<Customer>) query.list();
		if (listUser != null && listUser.isEmpty()) {
			return listUser.get(0);
		}
		return listUser.get(0);
	}

	@Transactional
	@SuppressWarnings("unchecked")
	public List<Customer> list() {
		
		String hql = "from Customer";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Customer> listUser = (List<Customer>) query.list();
		return listUser;
	}
}
package com.niit.collaboration.config;

import java.sql.SQLException;
import java.util.Properties;
import javax.sql.DataSource;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.hibernate5.HibernateTransactionManager;
import org.springframework.orm.hibernate5.LocalSessionFactoryBuilder;
import org.springframework.transaction.annotation.EnableTransactionManagement;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;

import com.niit.collaboration.model.Bllog;
import com.niit.collaboration.model.ColJobs;
import com.niit.collaboration.model.ColUser; 
import com.niit.collaboration.model.Customer;
import com.niit.collaboration.model.Event;
import com.niit.collaboration.model.Forum;


@EnableWebMvc
@Configuration
@ComponentScan(basePackages = "com.niit.collaboration")
@EnableTransactionManagement
public class ApplicationContextConfig {

	@Bean(name = "dataSource") 
	public DataSource getDataSource() {
		DriverManagerDataSource dataSource = new DriverManagerDataSource();		
		dataSource.setDriverClassName("oracle.jdbc.driver.OracleDriver");
		dataSource.setUrl("jdbc:oracle:thin:@localhost:1521/XE"); 
		dataSource.setUsername("sys as sysdba");
		dataSource.setPassword("system");		
		try {
			dataSource.getConnection();
			System.out.println("Connected !");
		} catch (SQLException e) {
			e.printStackTrace();
			System.out.println("Cannot find connection !");
		}
		return dataSource;
	} 

	@Autowired
	@Bean(name = "sessionFactory")
	public SessionFactory getSessionFactory(DataSource dataSource) {
		LocalSessionFactoryBuilder sessionBuilder = new LocalSessionFactoryBuilder(dataSource);

		sessionBuilder.addProperties(getHibernateProperties());
		sessionBuilder.scanPackages("com.niit.collaboration");

		sessionBuilder.addAnnotatedClasses(Customer.class);
		sessionBuilder.addAnnotatedClasses(ColUser.class);
		sessionBuilder.addAnnotatedClasses(Bllog.class);
		sessionBuilder.addAnnotatedClasses(Forum.class);
		sessionBuilder.addAnnotatedClasses(Event.class); 
		sessionBuilder.addAnnotatedClasses(ColJobs.class); 
		
		return sessionBuilder.buildSessionFactory(); 
	}

	private Properties getHibernateProperties() {
		Properties properties = new Properties();
		properties.put("hibernate.show_sql", "true");
		properties.put("hibernate.format_sql", "true");
		properties.put("hibernate.hbm2ddl.auto", "update");
		properties.put("hibernate.dialect", "org.hibernate.dialect.OracleDialect");
		return properties;
	}
 
	@Autowired
	@Bean(name = "transactionManager")
	public HibernateTransactionManager getTransactionManager(SessionFactory sessionFactory) {
		HibernateTransactionManager transactionManager = new HibernateTransactionManager(sessionFactory);
		return transactionManager;
	}
	
}
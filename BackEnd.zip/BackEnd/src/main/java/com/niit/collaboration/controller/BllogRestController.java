package com.niit.collaboration.controller;

	import java.util.List;

	import javax.servlet.http.HttpServletRequest;

	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.http.HttpStatus;
	import org.springframework.http.ResponseEntity;
	import org.springframework.web.bind.annotation.DeleteMapping;
	import org.springframework.web.bind.annotation.GetMapping;
	import org.springframework.web.bind.annotation.PathVariable;
	import org.springframework.web.bind.annotation.PostMapping;
	import org.springframework.web.bind.annotation.PutMapping;
	import org.springframework.web.bind.annotation.RequestBody;
	import org.springframework.web.bind.annotation.RequestMapping;
	import org.springframework.web.bind.annotation.RequestMethod;
	import org.springframework.web.bind.annotation.RestController;

import com.niit.collaboration.dao.BllogDAO;
import com.niit.collaboration.model.Bllog;


	 

	@RestController
	public class BllogRestController {

		
		@Autowired
		private BllogDAO bllogDAO;

		@Autowired
		private Bllog bllog;
		
		@GetMapping("/bllogs")
		public List getBllogs() {
			return bllogDAO.list();
		}

		@GetMapping("/bllogs/{id}")
		public ResponseEntity getBllog(@PathVariable("id") int id) {

			Bllog bllog = bllogDAO.get(id);
			if (bllog == null) {
				return new ResponseEntity("No Bllog found for ID " + id, HttpStatus.NOT_FOUND);
			} 

			return new ResponseEntity(bllog, HttpStatus.OK);
		}

		@RequestMapping(value="/bllogs", method=RequestMethod.POST)
		//@PostMapping(value = "/bllogs")
		public ResponseEntity<Bllog> createBllog(@RequestBody Bllog bllog) {
			
			bllogDAO.saveorupdate(bllog);

			return new ResponseEntity<Bllog>(bllog, HttpStatus.OK);
		}

		@DeleteMapping("/bllogs/{id}")
		public ResponseEntity deleteBllog(@PathVariable int id) {

			System.out.println(id);
			bllogDAO.delete(id);	
			
			return new ResponseEntity(id, HttpStatus.OK);

		}

		@PutMapping("/bllogs/{id}")
		public ResponseEntity updateBllog(@PathVariable int id, @RequestBody Bllog bllog) {

			bllogDAO.saveorupdate(bllog);

			if (null == bllog) {
				return new ResponseEntity("No Bllog found for ID " + id, HttpStatus.NOT_FOUND);
			}

			return new ResponseEntity(bllog, HttpStatus.OK);
		}


}

package com.niit.collaboration.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaboration.dao.UserDAO;
import com.niit.collaboration.model.ColUser;

public class UserTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context = new AnnotationConfigApplicationContext();
		context.scan("com.niit.collaboration");
		context.refresh();
		UserDAO userDAO = (UserDAO) context.getBean("userDAO");
		ColUser coluser = (ColUser) context.getBean("coluser");
		coluser.setUserid(121);
		coluser.setName("Nila");
		coluser.setPassword("Gunasekaran");
		coluser.setMail("nila.cse@gmail.com");
		coluser.setMobile("9090909090");
		coluser.setAddress("Tanjore");
		coluser.setUserrole("Student");
		System.out.println(coluser.getName() + " " + coluser.getMail());

		userDAO.saveorupdate(coluser);
		context.close();
	}
}

package com.niit.collaboration.test;

import java.util.Date;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaboration.dao.ForumDAO;
import com.niit.collaboration.model.Forum;

public class ForumTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.collaboration");
		context.refresh();
		ForumDAO forumDAO=(ForumDAO)context.getBean("forumDAO");
		Forum forum =(Forum)context.getBean("forum");
		forum.setForumid(100101);
		forum.setMessage("Friends");
		forum.setTime(new Date());
		System.out.println(forum.getForumid()+" "+forum.getMessage()+" "+forum.getTime());
				
		forumDAO.saveorupdate(forum);
		context.close(); 
	}
}

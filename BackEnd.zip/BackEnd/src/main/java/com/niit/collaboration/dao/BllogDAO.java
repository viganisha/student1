package com.niit.collaboration.dao;

	import java.util.ArrayList;
	import java.util.List;

	import org.hibernate.Query;
	import org.hibernate.Session;
	import org.hibernate.SessionFactory;
	import org.hibernate.Transaction;
	import org.springframework.beans.factory.annotation.Autowired;
	import org.springframework.stereotype.Component;
	import org.springframework.stereotype.Repository;
	import org.springframework.transaction.annotation.Transactional;

import com.niit.collaboration.model.Bllog;
import com.niit.collaboration.model.Bllog;


	@Repository("bllogDAO")
	public class BllogDAO {

		@Autowired
		private SessionFactory sessionFactory;

		public BllogDAO() {		
		}
		
		public BllogDAO(SessionFactory sessionFactory) {
			this.sessionFactory = sessionFactory;
		}
				
		public void saveorupdate(Bllog bllog) {
					
			Session ses = sessionFactory.openSession();
			Transaction tx=ses.beginTransaction(); 
			ses.saveOrUpdate(bllog);
			tx.commit();
			ses.close();
		}
	 
		@Transactional
		public void delete(int id) {
							
			Session sesDel = sessionFactory.openSession();
			Transaction tx=sesDel.beginTransaction();
			Bllog bllogToDelete = (Bllog) sesDel.load(Bllog.class, id);
			sesDel.delete(bllogToDelete);
			tx.commit();
			sesDel.close();
		}

		@Transactional
		public Bllog get(int id) {
			
			String hql = "from Bllog where id="+id;		 
			Query query = (Query<Bllog>) sessionFactory.getCurrentSession().createQuery(hql);
			List<Bllog> listBllog= (List<Bllog>) query.list();
			if (listBllog != null && listBllog.isEmpty()) {
				return listBllog.get(0);
			}
			return listBllog.get(0);
		}

		@Transactional
		@SuppressWarnings("unchecked")
		public List<Bllog> list() {
			
			String hql = "from Bllog";
			Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
			List<Bllog> listBllog = (List<Bllog>) query.list();
			return listBllog;
		}

}

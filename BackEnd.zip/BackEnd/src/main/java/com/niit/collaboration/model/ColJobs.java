package com.niit.collaboration.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

@Entity
@Table(name="ColJobs")
@Component
@Repository("job")
public class ColJobs {

	@Id
	private int jobid;
	private String description;
	private String requirement;
	private String company;
	
	public ColJobs(int jobid,String description,String requirement,String company){
		this.jobid = jobid;
		this.description = description;
		this.requirement = requirement;
		this.company = company;
	}
	
	public ColJobs(){
		
	}

	public int getJobid() {
		return jobid;
	}

	public void setJobid(int jobid) {
		this.jobid = jobid;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getRequirement() {
		return requirement;
	}

	public void setRequirement(String requirement) {
		this.requirement = requirement;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}
}

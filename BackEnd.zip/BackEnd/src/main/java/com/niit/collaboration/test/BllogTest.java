package com.niit.collaboration.test;

	import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaboration.dao.BllogDAO;
import com.niit.collaboration.model.Bllog;

	 public class BllogTest {
		
			public static void main(String[] args) { 
				AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
				context.scan("com.niit.collaboration");
				context.refresh();
				BllogDAO bllogDAO=(BllogDAO)context.getBean("bllogDAO");
				Bllog bllog=(Bllog)context.getBean("bllog");
				bllog.setId(111);
				bllog.setStatus("status") ;
				bllog.setDescription("description");
				bllog.setTitle("title");
				

				bllogDAO.saveorupdate(bllog); 

				context.close();
			}
		}







package com.niit.collaboration.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.collaboration.model.Event;

@Repository("eventDAO")
public class EventDAO {
 
	@Autowired
	private SessionFactory sessionFactory;

	public EventDAO() {		
	}
	
	public EventDAO(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
			
	public void saveorupdate(Event event) {
				
		Session ses = sessionFactory.openSession();
		Transaction tx=ses.beginTransaction(); 
		ses.saveOrUpdate(event);
		tx.commit();
		ses.close();
	}
 
	@Transactional
	public void delete(int id) {
						
		Session sesDel = sessionFactory.openSession();
		Transaction tx=sesDel.beginTransaction();
		Event evnToDelete = (Event) sesDel.load(Event.class, id);
		sesDel.delete(evnToDelete);
		tx.commit();
		sesDel.close();
	}

	@Transactional
	public Event get(int id) {
		
		String hql = "from Event where id="+id;		 
		Query query = (Query<Event>) sessionFactory.getCurrentSession().createQuery(hql);
		List<Event> listEvt = (List<Event>) query.list();
		if (listEvt != null && listEvt.isEmpty()) {
			return listEvt.get(0);
		}
		return listEvt.get(0);
	}

	@Transactional
	@SuppressWarnings("unchecked")
	public List<Event> list() {
		
		String hql = "from Event";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Event> listEvt = (List<Event>) query.list();
		return listEvt;
	}
}

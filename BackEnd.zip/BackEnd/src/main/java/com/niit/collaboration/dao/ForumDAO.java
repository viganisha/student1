package com.niit.collaboration.dao;

import java.util.List;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.niit.collaboration.model.Forum;

@Repository("forumDAO")
public class ForumDAO {

	@Autowired
	private SessionFactory sessionFactory;

	public ForumDAO() {		
	}
	
	public ForumDAO(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}
			
	public void saveorupdate(Forum forum) {
				
		Session ses = sessionFactory.openSession();
		Transaction tx=ses.beginTransaction(); 
		ses.saveOrUpdate(forum);
		tx.commit();
		ses.close();
	}
 
	@Transactional
	public void delete(int id) {
						
		Session sesDel = sessionFactory.openSession();
		Transaction tx=sesDel.beginTransaction();
		Forum forumToDelete = (Forum) sesDel.load(Forum.class, id);
		sesDel.delete(forumToDelete);
		tx.commit();
		sesDel.close();
	}

	@Transactional
	public Forum get(int id) {
		
		String hql = "from Forum where id="+id;		 
		Query query = (Query<Forum>) sessionFactory.getCurrentSession().createQuery(hql);
		List<Forum> listForum = (List<Forum>) query.list();
		if (listForum != null && listForum.isEmpty()) {
			return listForum.get(0);
		}
		return listForum.get(0);
	}

	@Transactional
	@SuppressWarnings("unchecked")
	public List<Forum> list() {
		
		String hql = "from Forum";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Forum> listForum = (List<Forum>) query.list();
		return listForum;
	}
}
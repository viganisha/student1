package com.niit.collaboration.test;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import com.niit.collaboration.dao.JobsDAO;
import com.niit.collaboration.model.ColJobs;


public class JobsTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.collaboration");
		context.refresh();
		
		JobsDAO jobsDAO=(JobsDAO)context.getBean("jobsDAO");
		ColJobs job =(ColJobs)context.getBean("job");
		job.setJobid(1010101);
		job.setCompany("TCS");
		job.setDescription("Java Developers");
		job.setRequirement("0-1 year");
		System.out.println(job.getCompany()+" "+job.getDescription());
				
		jobsDAO.saveorupdate(job);
		context.close(); 
	}
}

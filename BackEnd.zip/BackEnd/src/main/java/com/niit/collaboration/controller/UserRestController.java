package com.niit.collaboration.controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.niit.collaboration.dao.UserDAO;
import com.niit.collaboration.model.ColUser;

@RestController
public class UserRestController {


	@Autowired
	private UserDAO userDAO;

	@Autowired
	private ColUser coluser;
	 
	@GetMapping("/users")
	public List getUsers() {
		return userDAO.list();
	}

	@GetMapping("/users/{id}")
	public ResponseEntity getUser(@PathVariable("id") int id) {

		ColUser user = userDAO.get(id);
		if (user == null) {
			return new ResponseEntity("No User found for ID " + id, HttpStatus.NOT_FOUND);
		} 

		return new ResponseEntity(user, HttpStatus.OK);
	}

	@RequestMapping(value="/users", method=RequestMethod.POST)
	//@PostMapping(value = "/users")
	public ResponseEntity<ColUser> createUser(@RequestBody ColUser user) {
		
		userDAO.saveorupdate(user);

		return new ResponseEntity<ColUser>(user, HttpStatus.OK);
	}

	@DeleteMapping("/users/{id}")
	public ResponseEntity deleteUser(@PathVariable int id) {

		System.out.println(id);
		userDAO.delete(id);	
		
		return new ResponseEntity(id, HttpStatus.OK);

	}

	@PutMapping("/users/{id}")
	public ResponseEntity updateUser(@PathVariable int id, @RequestBody ColUser user) {

		userDAO.saveorupdate(user);

		if (null == user) {
			return new ResponseEntity("No User found for ID " + id, HttpStatus.NOT_FOUND);
		}

		return new ResponseEntity(user, HttpStatus.OK);
	}
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	public ResponseEntity<ColUser> login(@PathVariable ColUser user) {
		System.out.println("Login..");
		
		String name = user.getName();
		String pass = user.getPassword();
				
		boolean isVldUser = userDAO.isValidUser(name, pass);
		boolean isRole = userDAO.getValue(name, pass);
		
		System.out.println(isVldUser+" "+isRole);
		
		if (isVldUser == true && isRole == true) 
		{
			//ROLE_USER
			
		}
		else if(isVldUser == true && isRole == false){
			//ROLE_ADMIN
		}
		else
		{
			//Login.jsp			
		}
		return new ResponseEntity<ColUser>(user, HttpStatus.OK);
	}
}


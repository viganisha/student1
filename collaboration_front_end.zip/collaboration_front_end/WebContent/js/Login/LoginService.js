'use strict';
 
app.factory('LoginService', ['$http', '$q', function($http, $q){
	console.log("LoginService...")
	
    return {
            fetchAllUsers: function() {
            			return $http.get('http://localhost:8081/BackEnd/users')
                            .then(
                                    function(response){
                                    	console.log('fetchAllUsers response:' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while fetching User');
                                        return $q.reject(errResponse);
                                    }
                            );
            },
             
            createUser: function(User){
            	console.log('createUser User' + User)
            	var jsonObject = angular.toJson(User)
            	console.log('toJson:' + jsonObject)
                    	return $http.post('http://localhost:8081/BackEnd/users', jsonObject)            			
                            .then(
                                    function(response){
                                    	console.log('createUser response:' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while creating User');
                                        return $q.reject(errResponse);
                                    }
                            );
            },
             
            updateUser: function(User, id){
            	console.log('updateUser User' + UserDetails)
                    return $http.put('http://localhost:8081/BackEnd/users/'+id, User)
                            .then(
                                    function(response){
                                    	console.log('createUser :' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while updating User');
                                        return $q.reject(errResponse);
                                    }
                            );
            },
             
            isValidUser : function(id){
                    return $http.delete('http://localhost:8081/BackEnd/users/isValidUser',user)
                            .then(
                                    function(response){
                                    	$rootScope.globals={
                                    	currentUser:{
                                    		name:response.name
                                    	}		
                                    	};
                                       userid: response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while getting User');
                                        return $q.reject(errResponse);
                                    }
                            );
            },
            deleteUser: function(user){
            	console.log('deleteUser id' + id)
                     return $http.delete('http://localhost:8081/BackEnd/users/'+id)
                            .then(
                                    function(response){
                                    	console.log('deleteUser :' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while deleting User');
                                        return $q.reject(errResponse);
                                    }
                            );
            },     
         
    };
 
}]);
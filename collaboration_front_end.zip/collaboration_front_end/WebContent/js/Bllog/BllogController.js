 'use strict';

 
app.controller('BllogController', ['$scope', 'BllogService', function($scope, BllogService) {
	console.log("BllogController...")
          var self = this;
          self.bllog={id:'',description:'', title:'',status:' '};
          self.bllogs=[];
               
          self.fetchAllBllogs = function(){
        	  console.log(' self.fetchAllBllogs')
              BllogService.fetchAllBllogs()
                  .then(
                               function(d) {
                                    self.bllogs = d;
                                    console.log('bllogs...' + self.bllogs)
                               },
                                function(errResponse){
                                    console.error('Error while fetching Jobs');
                                }
                       );
          };
            
          self.createBllog = function(bllog){
        	  console.log('createBllog:' + bllog)
              BllogService.createBllog(bllog)
                      .then(
                      self.fetchAllBllogs, 
                              function(errResponse){
                                   console.error('Error while creating Bllog.');
                              } 
                  );
          };
 
         self.updateBllog = function(bllog, id){
        	 console.log('updateBllog:' + bllog)
        	 console.log('id:' + id)
              BllogService.updateBllog(bllog, id)
                      .then(
                              self.fetchAllBllogs, 
                              function(errResponse){
                                   console.error('Error while updating Bllog.');
                              } 
                  );
          };
 
         self.deleteBllog = function(id){
        	 console.log('deleteBllog:' + id)
              BllogService.deleteBllog(id)
                      .then(
                              self.fetchAllBllogs, 
                              function(errResponse){
                                   console.error('Error while deleting Bllog.');
                              } 
                  );
          };
 
          self.fetchAllBllogs();
 
          self.submit = function() {
             
                  console.log('Saving New Bllog', self.bllog);    
                  self.createBllog(self.bllog);
             
              self.reset();
          };
               
          self.edit = function(id){
              console.log('id to be edited', id);
              for(var i = 0; i < self.bllogs.length; i++){
                  if(self.bllogs[i].id === id) {
                     self.bllog = angular.copy(self.bllogs[i]);
                     break;
                  }
              }
          };
               
          self.remove = function(id){
              console.log('id to be deleted', id);
              if(self.bllog.id === id) {//clean form if the user to be deleted is shown there.
                 self.reset();
              }
              self.deleteBllog(id);
          };
 
           
          self.reset = function(){
        	  console.log('reset')
              self.bllog={id:'',description:'', title:'',status:' '};
              $scope.myForm.$setPristine(); //reset Form
          };
 
      }]);

'use strict';
 
app.factory('BllogService', ['$http', '$q', function($http, $q){
	console.log("BllogService...")
	
    return {
            fetchAllBllogs: function() {
            			return $http.get('http://localhost:8081/BackEnd/bllogs')
                            .then(
                                    function(response){
                                    	console.log('fetchAllBllogs response:' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while fetching Bllog');
                                        return $q.reject(errResponse);
                                    }
                            );
            },
             
            createBllog: function(Bllog){
            	console.log('createBllog Bllog' + Bllog)
            	var jsonObject = angular.toJson(Bllog)
            	console.log('toJson:' + jsonObject)
                    	return $http.post('http://localhost:8081/BackEnd/bllogs', jsonObject)            			
                            .then(
                                    function(response){
                                    	console.log('createUser response:' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while creating Bllog');
                                        return $q.reject(errResponse);
                                    }
                            );
            },
             
            updateBllog: function(Bllog, id){
            	console.log('updateBllog Bllog' + UserDetails)
                    return $http.put('http://localhost:8081/BackEnd/bllogs/'+id, Bllog)
                            .then(
                                    function(response){
                                    	console.log('createBllog :' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while updating Bllog');
                                        return $q.reject(errResponse);
                                    }
                            );
            },
             
            deleteBllog: function(id){
            	console.log('deleteBllog id' + id)
                    return $http.delete('http://localhost:8081/BackEnd/bllogs/'+id)
                            .then(
                                    function(response){
                                    	console.log('deleteBllog :' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while deleting Bllog');
                                        return $q.reject(errResponse);
                                    }
                            );
            }
         
    };
 
}]);
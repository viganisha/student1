'use strict';
 
app.factory('JobRegisterService', ['$http', '$q', function($http, $q){
	console.log("JobRegisterService...")
	
    return {
            fetchAllJobs: function() {
            			return $http.get('http://localhost:8081/BackEnd/jobs')
                            .then(
                                    function(response){
                                    	console.log('fetchAllJobs response:' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while fetching Job');
                                        return $q.reject(errResponse);
                                    }
                            );
            },
             
            createJob: function(Job){
            	console.log('createJob Job' + Job)
            	var jsonObject = angular.toJson(Job)
            	console.log('toJson:' + jsonObject)
                    	return $http.post('http://localhost:8081/BackEnd/jobs', jsonObject)            			
                            .then(
                                    function(response){
                                    	console.log('createUser response:' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while creating Job');
                                        return $q.reject(errResponse);
                                    }
                            );
            },
             
            updateJob: function(Job, id){
            	console.log('updateJob Job' + UserDetails)
                    return $http.put('http://localhost:8081/BackEnd/jobs/'+id, Job)
                            .then(
                                    function(response){
                                    	console.log('createJob :' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while updating Job');
                                        return $q.reject(errResponse);
                                    }
                            );
            },
             
            deleteJob: function(id){
            	console.log('deleteJob id' + id)
                    return $http.delete('http://localhost:8081/BackEnd/jobs/'+id)
                            .then(
                                    function(response){
                                    	console.log('deleteJob :' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while deleting Job');
                                        return $q.reject(errResponse);
                                    }
                            );
            }
         
    };
 
}]);
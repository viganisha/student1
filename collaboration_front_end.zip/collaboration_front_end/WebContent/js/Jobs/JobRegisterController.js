 'use strict';

 
app.controller('JobRegisterController', ['$scope', 'JobRegisterService', function($scope, JobRegisterService) {
	console.log("JobRegisterController...")
          var self = this;
          self.job={jobid:'',description:'',requirement:'',company:''};
          self.jobs=[];
               
          self.fetchAllJobs = function(){
        	  console.log(' self.fetchAllJobs')
              JobRegisterService.fetchAllJobs()
                  .then(
                               function(d) {
                                    self.jobs = d;
                                    console.log('jobs...' + self.jobs)
                               },
                                function(errResponse){
                                    console.error('Error while fetching Jobs');
                                }
                       );
          };
            
          self.createJob = function(job){
        	  console.log('createJob:' + job)
              JobRegisterService.createJob(job)
                      .then(
                      self.fetchAllJobs, 
                              function(errResponse){
                                   console.error('Error while creating Job.');
                              } 
                  );
          };
 
         self.updateJob = function(job, id){
        	 console.log('updateJob:' + job)
        	 console.log('id:' + id)
              JobRegisterService.updateJob(job, id)
                      .then(
                              self.fetchAllJobs, 
                              function(errResponse){
                                   console.error('Error while updating Job.');
                              } 
                  );
          };
 
         self.deleteJob = function(id){
        	 console.log('deleteJob:' + id)
              JobRegisterService.deleteJob(id)
                      .then(
                              self.fetchAllJobs, 
                              function(errResponse){
                                   console.error('Error while deleting Job.');
                              } 
                  );
          };
 
          self.fetchAllJobs();
 
          self.submit = function() {
             
                  console.log('Saving New Job', self.job);    
                  self.createJob(self.job);
             
              self.reset();
          };
               
          self.edit = function(id){
              console.log('id to be edited', id);
              for(var i = 0; i < self.jobs.length; i++){
                  if(self.jobs[i].id === id) {
                     self.job = angular.copy(self.jobs[i]);
                     break;
                  }
              }
          };
               
          self.remove = function(id){
              console.log('id to be deleted', id);
              if(self.job.id === id) {//clean form if the user to be deleted is shown there.
                 self.reset();
              }
              self.deleteJob(id);
          };
 
           
          self.reset = function(){
        	  console.log('reset')
              self.job={jobid:'',description:'',requirement:'',company:''};
              $scope.myForm.$setPristine(); //reset Form
          };
 
      }]);

 'use strict';

 
app.controller('EventController', ['$scope', 'EventService', function($scope, EventService) {
	console.log("EventController...")
          var self = this;
          self.event={eventid:'',description:'',Title:''};
          self.events=[];
               
          self.fetchAllEvents = function(){
        	  console.log(' self.fetchAllEvents')
              EventService.fetchAllEvents()
                  .then(
                               function(d) {
                                    self.events = d;
                                    console.log('events...' + self.events)
                               },
                                function(errResponse){
                                    console.error('Error while fetching events');
                                }
                       );
          };
            
          self.createEvent = function(event){
        	  console.log('createJob:' + event)
              EventService.createJob(event)
                      .then(
                      self.fetchAllEvents, 
                              function(errResponse){
                                   console.error('Error while creating Event.');
                              } 
                  );
          };
 
         self.updateEvent = function(event, id){
        	 console.log('updateEvent:' + event)
        	 console.log('id:' + id)
              EventService.updateEvent(event, id)
                      .then(
                              self.fetchAllEvents, 
                              function(errResponse){
                                   console.error('Error while updating Event.');
                              } 
                  );
          };
 
         self.deleteEvent = function(id){
        	 console.log('deleteEvent:' + id)
              EventService.deleteEvent(id)
                      .then(
                              self.fetchAllEvents, 
                              function(errResponse){
                                   console.error('Error while deleting Event.');
                              } 
                  );
          };
 
          self.fetchAllEvents();
 
          self.submit = function() {
             
                  console.log('Saving New Event', self.event);    
                  self.createEvent(self.event);
             
              self.reset();
          };
               
          self.edit = function(id){
              console.log('id to be edited', id);
              for(var i = 0; i < self.events.length; i++){
                  if(self.events[i].id === id) {
                     self.event = angular.copy(self.events[i]);
                     break;
                  }
              }
          };
               
          self.remove = function(id){
              console.log('id to be deleted', id);
              if(self.event.id === id) {//clean form if the user to be deleted is shown there.
                 self.reset();
              }
              self.deleteEvent=(id);
          };
 
           
          self.reset = function(){
        	  console.log('reset')
              self.event={eventid:'',description:'',Title:''};
              $scope.myForm.$setPristine(); //reset Form
          };
 
      }]);

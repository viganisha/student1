'use strict';
 
app.factory('EventService', ['$http', '$q', function($http, $q){
	console.log("EventService...")
	
    return {
            fetchAllEvents: function() {
            			return $http.get('http://localhost:8081/BackEnd/events')
                            .then(
                                    function(response){
                                    	console.log('fetchAllEvents response:' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while fetching Event');
                                        return $q.reject(errResponse);
                                    }
                            );
            },
             
            createEvent: function(Event){
            	console.log(' createEvent Event' + Event)
            	var jsonObject = angular.toJson(Event)
            	console.log('toJson:' + jsonObject)
                    	return $http.post('http://localhost:8081/BackEnd/events', jsonObject)            			
                            .then(
                                    function(response){
                                    	console.log('createEvent response:' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while creating Event');
                                        return $q.reject(errResponse);
                                    }
                            );
            },
             
            updateEvent: function(Event, id){
            	console.log('updateEvent Event' + UserDetails)
                    return $http.put('http://localhost:8081/BackEnd/events/'+id, Event)
                            .then(
                                    function(response){
                                    	console.log('createEvent:' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while updating Event');
                                        return $q.reject(errResponse);
                                    }
                            );
            },
             
            deleteEvent: function(id){
            	console.log('deleteEvent id' + id)
                    return $http.delete('http://localhost:8081/BackEnd/events/'+id)
                            .then(
                                    function(response){
                                    	console.log('deleteEvent :' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while deleting Event');
                                        return $q.reject(errResponse);
                                    }
                            );
            }
         
    };
 
}]);
<!--ngRoute is build in module in angular js used for navigation (ModelAndView) -->
var app = angular.module('myApp', ['ngRoute']);



app.config(['$routeProvider',function($routeProvider) {
	
	  $routeProvider

	   .when('/home', {
	    templateUrl : 'views/home.html',
	   // controller  : 'HomeController'
	  })
	  
	    .when('/jobregister', {
	    templateUrl : 'views/JobRegister.html',
	    //controller  : 'js/Jobs/JobRegisterController'
	  })
	  /*  
	   .when('/manageUser', {
	    templateUrl : 'admin/manage_users.html',
	    controller  : 'AdminController'
	  })
	  

	
	   .when('/about', {
	    templateUrl : 'about/about.html',
	    controller  : 'AboutController'
	  })
		      */
 	
	   .when('/Bllog', {
	    templateUrl : 'views/Bllog.html',
	    //controller  : 'BllogController'
	  })
	  
	   .when('/Event', {
	    templateUrl : 'views/Event.html',
	    //controller  : 'EventController'
	  })
	 
	   .when('/login', {
	    templateUrl : 'views/Login.html',
	   // controller  : 'LoginController'
	   
	  })
	
	   .when('/Register', {
	    templateUrl : 'views/Register.html',
	    //controller  : 'js/Register/RegisterController'
	  })

	   .otherwise({redirectTo: '/'});
	}]);


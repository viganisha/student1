<!--ngRoute is build in module in angular js used for navigation (ModelAndView) -->
var app = angular.module('myApp', ['ngRoute']);



app.config(['$routeProvider',function($routeProvider) {
	
	  $routeProvider
/*
	  .when('/', {
	    templateUrl : 'Home/home.html',
	    controller  : 'HomeController'
	  })
	  
	    .when('/job_opportunities', {
	    templateUrl : 'job/job.html',
	    controller  : 'JobController'
	  })
	  
	   .when('/manageUser', {
	    templateUrl : 'admin/manage_users.html',
	    controller  : 'AdminController'
	  })
	  

	  .when('/blog', {
	    templateUrl : 'blog/blog.html',
	    controller  : 'BlogController'
	  })
	  
	  
	  .when('/event', {
	    templateUrl : 'event/event.html',
	    controller  : 'EventController'
	  })

	  .when('/about', {
	    templateUrl : 'about/about.html',
	    controller  : 'AboutController'
	  })
	  
	   .when('/login', {
	    templateUrl : 'login/Login.html',
	    controller  : 'LoginController'
	  })
	  */
	   .when('/Register', {
	    templateUrl : 'Register/Register.html',
	    controller  : 'RegisterController'
	  })

	  .otherwise({redirectTo: '/'});
	}]);


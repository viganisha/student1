'use strict';
 
app.factory('RegistrationService', ['$http', '$q', function($http, $q){
	console.log("RegistrationService...")
	
    return {
         
            fetchAllUsers: function() {
                    return $http.get('http://localhost:8081/Collaboration_Platform_back_end/User')
                            .then(
                                    function(response){
                                    	console.log('fetchAllUsers response:' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while fetching User');
                                        return $q.reject(errResponse);
                                    }
                            );
            },
             
            createUser: function(User){
            	console.log('createUser User' + User)
            	var jsonObject = angular.toJson(User)
            	console.log('toJson:' + jsonObject)
                    return $http.post('http://localhost:8081/Collaboration_Platform_back_end/User', jsonObject)
                            .then(
                                    function(response){
                                    	console.log('createUser response:' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while creating User');
                                        return $q.reject(errResponse);
                                    }
                            );
            },
             
            updateUser: function(User, id){
            	console.log('updateUser User' + UserDetails)
                    return $http.put('http://localhost:8081/Collaboration_Platform_back_end/User'+id, User)
                            .then(
                                    function(response){
                                    	console.log('createUser :' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while updating User');
                                        return $q.reject(errResponse);
                                    }
                            );
            },
             
            deleteUser: function(id){
            	console.log('deleteUser id' + id)
                    return $http.delete('http://localhost:8081/Collaboration_Platform_back_end/User'+id)
                            .then(
                                    function(response){
                                    	console.log('deleteUser :' +response.data)
                                        return response.data;
                                    }, 
                                    function(errResponse){
                                        console.error('Error while deleting User');
                                        return $q.reject(errResponse);
                                    }
                            );
            }
         
    };
 
}]);
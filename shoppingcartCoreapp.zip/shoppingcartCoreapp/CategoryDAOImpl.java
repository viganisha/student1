package com.niit.shoppingcartCoreapp;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.TransactionManagementConfigurationSelector;
import org.springframework.transaction.annotation.Transactional;
//import org.springframework.transaction.event.TransactionalEventListener;
import java.util.List;

@Repository("categoryDAO")
public class CategoryDAOImpl implements CategoryDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	public CategoryDAOImpl() {
	}

	public CategoryDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void saveOrUpdate(Category category) {
		Session ses = sessionFactory.openSession();
		Transaction tx =ses.beginTransaction();
		
		/*System.out.println("CATEGORYDAOIMPL: "+category.getId()+" "+category.getName());
		category.setId(category.getId());
		category.setName(category.getName());
		category.setDescription(category.getDescription());*/
		ses.saveOrUpdate(category);
		tx.commit();
		ses.close();
	}

	@Transactional
	public void delete(int id) {
		Category CategoryToDelete = new Category();
		CategoryToDelete.setId(id);
		sessionFactory.getCurrentSession().delete(id);
	}

	@Transactional
	public Category get(int id) {
		String hql = "from Category where id=+";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Category> listCategory = (List<Category>) query.list();
		if (listCategory != null && listCategory.isEmpty()) {
			return listCategory.get(0);
		}
		return null;
	}

	@Transactional
	@SuppressWarnings("unchecked")
	public List<Category> list() {
		String hql = "from Category";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Category> listCategory = (List<Category>) query.list();
		return listCategory;
	}
}
package com.niit.shoppingcartCoreapp;

import java.util.List;

public interface SupplierDAO {
	public List<Supplier> list();
	public Supplier get(int id);
	public void saveorupdate(Supplier Supplier);
	public void delete(int id);
}
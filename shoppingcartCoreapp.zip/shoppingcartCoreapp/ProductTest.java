package com.niit.shoppingcartCoreapp;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class ProductTest {
	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcartCoreapp");
		context.refresh();
		ProductDAO productDAO=(ProductDAO)context.getBean("productDAO");
		Product product =(Product)context.getBean("product");
		product.setId(11);
		product.setName("gsna11");
		product.setDescription("gsdes111s");
		product.setPrice(50000);
		System.out.println(product.getId()+" "+product.getName()+" "+product.getDescription());
		productDAO. saveorupdate(product);
	}
}

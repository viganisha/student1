package com.niit.shoppingcartCoreapp;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;
//import org.springframework.transaction.event.TransactionalEventListener;
import java.util.List;

@Repository("supplierDAO")
public class SupplierDAOImpl implements SupplierDAO {
	
	@Autowired
	private SessionFactory sessionFactory;

	public SupplierDAOImpl() {
	}

	public SupplierDAOImpl(SessionFactory sessionFactory) {
		this.sessionFactory = sessionFactory;
	}

	public void saveorupdate(Supplier Supplier) {
		Session ses = sessionFactory.openSession();
		Transaction tx=ses.beginTransaction();
		ses.saveOrUpdate(Supplier);
		tx.commit();
		ses.close();
	}

	@Transactional
	public void delete(int id) {
		Supplier SupplierToDelete = new Supplier();
		SupplierToDelete.setId(id);
		sessionFactory.getCurrentSession().delete(id);
	}

	@Transactional
	public Supplier get(int id) {
		String hql = "from Supplier where id=+";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Supplier> listSupplier = (List<Supplier>) query.list();
		if (listSupplier != null && listSupplier.isEmpty()) {
			return listSupplier.get(0);
		}
		return null;
	}

	@Transactional
	@SuppressWarnings("unchecked")
	public List<Supplier> list() {
		String hql = "from Supplier";
		Query query = (Query) sessionFactory.getCurrentSession().createQuery(hql);
		List<Supplier> listSupplier = (List<Supplier>) query.list();
		return listSupplier;
	}
}
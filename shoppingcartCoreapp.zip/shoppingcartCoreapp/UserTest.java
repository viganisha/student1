package com.niit.shoppingcartCoreapp;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class UserTest {

	public static void main(String[] args) {
		AnnotationConfigApplicationContext context=new AnnotationConfigApplicationContext();
		context.scan("com.niit.shoppingcartCoreapp");
		context.refresh();
		UserDAO userDAO=(UserDAO)context.getBean("userDAO");
		User user =(User)context.getBean("user");
		user.setId(11);
		user.setName("viganisha");
		user.setPassword("hello");
		user.setMobile(2345);
		user.setMail("gs");
		user.setAddress("CHENNAI");
		System.out.println(user.getId()+" "+user.getName()+" "+user.getAddress());
		userDAO.saveorupdate(user);
	}
}
